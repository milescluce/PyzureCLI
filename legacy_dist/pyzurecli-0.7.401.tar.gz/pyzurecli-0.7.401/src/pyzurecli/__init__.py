from .factory import AzureCLI

az = AzureCLI
