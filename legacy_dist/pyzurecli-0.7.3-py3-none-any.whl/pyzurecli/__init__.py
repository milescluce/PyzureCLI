from toomanysessions import GraphAPI

GraphAPI = GraphAPI
from .factory import AzureCLI

az = AzureCLI
from .pyzureserver import PyzureServer
